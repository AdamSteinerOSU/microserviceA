import time
import os

user_input = input('Enter the event topic (all lowercase, no spaces): ')  # get user input

with open('event.txt', 'w', encoding="utf-8") as f:
    f.write(user_input)

with open('randomNumber.txt', 'w', encoding="utf-8") as f:  #
    f.write("run")

time.sleep(8)

with open('writeEvent.txt', 'r', encoding="utf-8") as f:
    idea_data = f.read()

if idea_data in 'Event Topic Not Found':
    print(idea_data)
else:
    try:
        with open(os.path.join('ideas', user_input, idea_data), 'r', encoding="utf-8") as f:
            idea = f.read()
        print(idea)
    except FileNotFoundError:
        print("Invalid topic")

