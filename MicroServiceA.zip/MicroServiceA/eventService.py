import os
import time


f = open('event.txt', 'r', encoding="utf-8")

idea_name = f.read()


while True:
    f = open('event.txt', 'r', encoding="utf-8")

    idea_name = f.read()
    file_list = os.listdir('ideas')

    if idea_name in file_list:
        list_ideas = os.listdir('ideas/' + idea_name)  # get a directory of the image folder
        length = len(list_ideas)  # get length of the image folder
        with open('randomNumber.txt', encoding="utf-8") as f:
            read_data = f.read()  # read the random number from the text file, and save it as read_data
        if read_data.isnumeric():
            idea_selected = int(read_data)  # convert the random number into an int
            idea_selected = idea_selected % length  # if i >= to number of ideas, modulo i by the size of the image set

            idea = list_ideas[idea_selected]  # get the selected image

            with open('writeEvent.txt', 'w', encoding="utf-8") as f:
                f.write(idea)  # write the selected idea to text file

    else:
        with open('writeEvent.txt', 'w', encoding="utf-8") as f:
            f.write('Event Topic Not Found')

    time.sleep(1)
